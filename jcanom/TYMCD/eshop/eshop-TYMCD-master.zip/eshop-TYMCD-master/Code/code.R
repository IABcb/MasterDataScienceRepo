library(dplyr)

# Leemos los datos del csv. Indicamos que la cadena "nc" es el equivalente a NA
data <- read.csv("Data/eshop.csv",sep = ";",na.strings = "nc")

# Establecemos los nombres de los target que nos interesan
target_home <- "eshop.home"
target_work <- "eshop.work"

# Homogeneizamos las etiquetas de los factores de los dos targets
levels(data[,target_work]) <- c("yes-eshop-work","no-eshop-work")

# Hacemos un conteo con summary sobre las target
summary(data[,target_home]) # Hay un NA
summary(data[,target_work]) # Hay dos NA

# Dividimos los datos con los dos target para manejarlos con comodidad y limpiamos los NAs
data_home <- filter(data[,colnames(data)!=target_work],!is.na(eshop.home)) %>% na.omit()
data_work <- filter(data[,colnames(data)!=target_home],!is.na(eshop.work)) %>% na.omit()

descriptive <- function(x){
  print(summary(x))
  plot(x,las=2)
}

# Descriptivo data_home
sapply(data_home[which(data_home$eshop.home=="yes-eshop-home"),],descriptive)
sapply(data_home[which(data_home$eshop.home=="no-eshop-home"),],descriptive)

# Descriptivo data_work
sapply(data_work[which(data_work$eshop.work=="yes-eshop-work"),],descriptive)
sapply(data_work[which(data_work$eshop.work=="no-eshop-work"),],descriptive)

# Frecuencias de compras en casa y trabajo
group_by(data_home,eshop.home) %>% summarise(n=n()) %>% mutate(freq=n/sum(n))
group_by(data_work,eshop.work) %>% summarise(n=n()) %>% mutate(freq=n/sum(n))

# Contraste hipótesis
# H_0 --> %eshop.home == %eshop.work
# H_1 --> %eshop.home != %eshop.work
eshoppers <- c(282,96)
totales <- c(2142,2142)

prop.test(eshoppers, totales, conf.level = .95, alternative = "two.sided")
# p < 2.2e-16 --> H_0 es válida? NO! p-value < 0.05
