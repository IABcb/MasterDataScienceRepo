#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 15 21:25:00 2016

@author: Raul Sanchez Martin
"""

import sys
import json
from CityToState import CityToStateDict
import re
import time

def GetScoresDic(fileName):
    '''
    Function that returns a dictionary where each key is a word
    and the value of that key is its score.
    The function has one input, the file name of the .txt file
    where the score of each word is specified
    '''
    wordScore = {}
    fileScoresDic = open(fileName)
    for line in fileScoresDic:
        word, score = line.split("\t")
        if score[-1] == "\n":
            score = score[:-1]
        wordScore[word] = int(score)
    return wordScore
    
def GetStateFromCity(city, CityToStateDic):
    '''
    Function that returns the State of a city from the US giving
    two arguments: the name of the city ("city"); and a dictionary
    where each key-value pair is defined as the name of a city of the US 
    and the corresponding State. This dictionary has to be obtained 
    beforehand
    '''
    state = None
    if city in CityToStateDic:
        state = CityToStateDic[city]
    return state
    
def FilterTweets(jsonLine, CityToStateDic):
    '''
    This function takes as an argument a Tweet in JSON format ("jsonLine"). 
    In addition, a dicctionary ("CityToStateDic"), where each key-value pair is 
    defined as the name of a city of the US and its corresponding State, has to
    be included as an input. This dictionary has to be obtained beforehand.
    This function returns the text and the state of each Tweet (as a dictionary) 
    only if the following conditions are met:
        * The country is US
        * The specified type of place from where the Tweet was made is "city"
        * The language is English
    If that conditions are not met, a "None" value is returned
    '''
    place = None
    countryCode = None
    text = None
    state = None
    try:
        place = jsonLine["place"]
        text = jsonLine["text"]
        language = jsonLine["lang"]
    except KeyError:
        pass
    if place:
        countryCode = place["country_code"]
        if countryCode == "US" and place["place_type"] == "city":
            city = place["name"]
            state = GetStateFromCity(city, CityToStateDic)                  
    
    if text and state and language == "en":
        dic = {"state":state, "text": text}
        return dic
    else:
        return None
        


def ApplyScoresWords(text, scoresDic):
    '''
    This function calculates the score of a given text ("text") as a function
    of predefined word-score relation, which has to be provided as a dictionary
    ("scoresDic")
    '''
    totalScore = 0
    for word in text.split():
        scoreWord = 0
        try:
            scoreWord = scoresDic[word]
        except KeyError:
            pass
        totalScore += scoreWord
    return totalScore

#First we obtain a dictionary where the score of each word is included    
scoresDic = GetScoresDic("AFINN-111.txt")

def WordSplitter(text):
    '''
    This function splits the text into space separated words in order
    to calculate trending topics in the reducer process.
    '''
    splitted_text = text.split(" ")
    words_dicc = {}
    for word in splitted_text:
        if word in words_dicc:
            words_dicc[word] += 1
        else:
            words_dicc[word] = 1
    return words_dicc

def is_word(word):
    '''
    This function analize the word in order to delete every no-word
    '''
    patron = re.compile("^[a-z,A-Z]+$")
    return patron.match(word) != None


def is_tweet(word):
    is_tweet1 = False
    try:
        word = str(word)
        if len(word) > 0:
            if word[0] == "#" and ":" not in word:
                is_tweet1 = True
            else:
                is_tweet1 = False
        else:
            is_tweet1 = False
    except:
        pass
    return is_tweet1

    
def key_value_producer(filtered_line, score, words_dicc):
    '''
    This function gives an pair of key value, where the key has two different pair of values:
    "state", The state: to determinate the happiness with the text evaluation.
    "word", the word: to calculate the word count process
    The value has a number. This number could be the happiness score or the word count. 
    '''
    word_keys = words_dicc.keys()
    for word_key in word_keys: 
        if is_tweet(word_key):
            print '{0}\t{1}'.format(['w', str(word_key[1:])], words_dicc[word_key])
    print '{0}\t{1}'.format(['s', filteredLine["state"]], score)

#Only for test locally
init_time = time.time()
      
for line in sys.stdin:
    
    sys.path.append('.')
    # Get an JSON object from each line
    try:
        jsonLine = json.loads(line, encoding='utf-8')
    	    
        # Then we filter the Tweets and we only keep that ones that are or our 
        # interest
        filteredLine = FilterTweets(jsonLine, CityToStateDict)
    	    
    	    
        if filteredLine:
            text = filteredLine["text"]
    		
            # For each Tweet of interest, we get the score
            score = ApplyScoresWords(text, scoresDic)
    
            # We split the text in order to calculate TT's        
            words_dicc = WordSplitter(text)
    		    
            # We produce a pair of key - value for the trending topic calculator and the happiness process
            key_value_producer(filteredLine, score, words_dicc)
    except:
        pass
#Only for test locally
sys.stderr.write("Final mapper time: {0}\n".format(str(time.time()-init_time)))
        
            
